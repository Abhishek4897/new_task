<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function index()
	{
		// $this->load->model('Home_model');
      	$data['page_name'] = 'USer List';
		$this->load->view('index',$data);
	}

	public function add_user(){
		 if($this->input->post('add'))
	        {	
	        	$captcha_insert = $this->input->post('captcha');
                $contain_sess_captcha = $this->session->userdata('valuecaptchaCode');
                if ($captcha_insert == $contain_sess_captcha) {
        			$insert_data=$this->Home_model->add_user();
	            if($insert_data==""){
	            	$this->session->set_flashdata("fail","<script>swal({ title: 'Warning', text: 'User not added. Try again later.', timer: 3000, buttons: false, icon: 'warning' });</script>"); 
	 		     } else{
	 		     	$this->session->set_flashdata("success","<script>swal({ title: 'Success', text: 'User added successfully', timer: 3000, buttons: false, icon: 'success' });</script>");   
	 		     }
            }
            else{
                  $this->session->set_flashdata("fail","<script>swal({ title: 'Warning', text: 'Invalid captcha.', timer: 3000, buttons: false, icon: 'warning' });</script>");  
					
                }
	            
	          
           } else{
           $this->session->set_flashdata("fail","<script>swal({ title: 'Warning', text: 'User not added. Try again later.', timer: 3000, buttons: false, icon: 'warning' });</script>");    
	       }
	        redirect($_SERVER['HTTP_REFERER']);
		
	}

	public function update_user(){
		 if($this->input->post('update'))
	        {
	            $update_data=$this->Home_model->update_user();
	           $this->session->set_flashdata("success","<script>swal({ title: 'Success', text: 'User updated successfully', timer: 3000, buttons: false, icon: 'success' });</script>");
	          
           } else{
           
	          $this->session->set_flashdata("fail","<script>swal({ title: 'Warning', text: 'User not updated. Try again later.', timer: 3000, buttons: false, icon: 'warning' });</script>");    
	       }
	        redirect($_SERVER['HTTP_REFERER']);
		
	}

	public function delete_user(){
		if($this->input->post('id'))
	        {
	            $result=$this->Home_model->delete_user();
	            if($result){
	            	echo 1;  
	 		     } else{
	 		     	echo 0;
	 		     }
	          
           }
	}

	public function fetch_userdata(){
		$postData = $_POST;
            $draw="";
            $start="";
            $rowperpage="";
            $response = array(); 
            $data = array();
            if($_POST){
            $draw = $postData['draw'];
            $start = $postData['start'];
            $rowperpage = $postData['length']; // Rows display per page
            $columnIndex = $postData['order'][0]['column']; // Column index
            $columnName = $postData['columns'][$columnIndex]['data']; // Column name
            $columnSortOrder = $postData['order'][0]['dir']; // asc or desc
            }
                $l = $this->db->get('user')->num_rows();
                $totalRecords =$l;
           
			     $output=$this->db->from('user');
    					$this->db->order_by("id", "desc");
    					$this->db->limit($rowperpage, $start);
    					$output = $this->db->get()->result();
            $i=$start + 1;
            
            foreach($output as $o){
                  $action = "";
                  $status="";
                  $badge='';
			      $tatus="";
			      $image="";
               
                            if($o->status==0){
						           $badge= 'danger';
						           $tatus="Deactive";
						           
						       }elseif($o->status==1){
						       $badge= 'success';
						       $tatus="Active";
						       }
						       $status='<span class="btn btn-'.$badge.' btn-sm">'.$tatus.'</span>';
						      
						      
							$action= '
							<a style="color:green;cursor:pointer;" data-toggle="modal" data-target="#mymodal" data-pageid="Update User" data-id="'.base_url().'home/view_modal/update_user/'.$o->id.'" id="menu"><i class="fa fa-pencil" aria-hidden="true"></i></a>
							<a style="color:red;cursor:pointer;" onclick="delete_user('.$o->id.')"><i class="fa fa-trash" aria-hidden="true"></i></a>'; 
                                
                        $data[] = array(
                           'sr_no'=>$i,
                           'name'=>$o->name,
                           'email'=>$o->email,
                           'mobile'=>$o->mobile,
                           'dob'=>$o->dob,
                           'bio'=>$o->bio,
                           'status'=>$status,
                           'action'=>$action,
                           ); 
            $i++;    
            }
         $response = array(
                    "draw" => intval($draw),
                    "recordsTotal"  => $totalRecords,
                    "recordsFiltered" => $totalRecords,
                    "data" => $data
                );
               
    echo json_encode($response);
	}

	public function view_modal($page_name = '' , $param2 = '' , $param3 = '', $param4 = ''){
        $data['param2']     =   $param2;
        $data['param3']     =   $param3;
        $data['param4']     =   $param4;
        $this->load->view($page_name.'.php' ,$data);
    }

}
