<script>
		 var dataTables =     $('#table_id').DataTable( {
                "processing": true,
                "serverSide": true,
                "ordering":true,
                "searching": false,
                "ajax": {
                            "url": "home/fetch_userdata",
                            "type": "POST",
                            "data": function(data){
                              // Read values
                            
                              var searchs = $('#search').val();
                              // Append to data
                              data.textfield = searchs;
                             
                            }
                        },
                        "columns": [
                            { data: 'sr_no' },
                            { data: 'name' },
                            { data: 'email' },
                            { data: 'mobile' },
                            { data: 'dob' },
                            { data: 'bio' },
                            
                        ]
               
            } );
    // $('#table_id').DataTable();
     $(document).on('click', '#menu', function(e) {
            e.preventDefault();
            $('#mymodal').modal('show');
            var url = $(this).data('id'); // it will get action urlpageid
             var page_title = $(this).data('pageid'); // it will get page title
            $('#dynamic-content').html(''); // leave it blank before ajax call
            $('#page_title').html(page_title);
            $('#modal_loader').show(); // load ajax loader
            $.ajax({
                    url: url,
                    type: 'POST',
                    dataType: 'html'
                })
            .done(function(data) {
                console.log(data);
                $('#dynamic-content').html('');
                $('#dynamic-content').html(data); // load response 
                $('#modal_loader').hide(); // hide ajax loader 
            })
            .fail(function() {
                $('#dynamic-content').html('<i class="glyphicon glyphicon-info-sign"></i> Something went wrong, Please try again...');
                $('#modal-loader').hide();
            });
        });

    

</script>