<?php echo ($this->session->flashdata('fail'))?$this->session->flashdata('fail'):'';?>
<?php echo ($this->session->flashdata('success'))?$this->session->flashdata('success'):'';?></body>
</html>