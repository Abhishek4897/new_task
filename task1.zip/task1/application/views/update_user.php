<?php  $user_details=$this->Home_model->list_user($param2);?>
    <form action="<?=base_url('home/update_user')?>" method="post" id="UploadForm" name="address_form_add" enctype="multipart/form-data">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label for="first_name">Name</label>
                    <input type="text" name="name" value="<?=$user_details->name;?>" class="form-control" id="name" required>
                 </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="email">E-mail:</label>
                    <input type="email" name="email" value="<?=$user_details->email;?>" class="form-control" id="email" required>
                 </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="number">Mobile</label>
                    <input type="text" value="<?=$user_details->mobile;?>" onKeyPress="if(this.value.length==10) return false;"  pattern="[6789][0-9]{9}" name="mobile" class="form-control"  id="number" required ="">
                 </div>
            </div>
             <div class="col-md-12">
                <div class="form-group">
                    <label for="address">Image</label>
                    <input type="file" name="image"  accept="image/*" value="<?=$user_details->image;?>"class="form-control">
                 </div>
            </div>
           
           <div class="col-md-12" style="margin-top: 10px;">
                <button type="submit" id="submit_btn" name="update" value="<?=$user_details->id;?>" class="btn btn-success">Update</button>
            </div>
           
            
        </div>
    </form>    