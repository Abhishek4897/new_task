<?php include('includes/header.php');?>
	<section class="mt-70">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="card shadow-sm">
						<div class="card-header bg-white">
							<div class="row">
								<div class="col-md-6">
									<h4>Users List</h4>
								</div>
								<div class="col-md-6 text-right">
									<button  type="button" data-toggle="modal" data-target="#mymodal" data-pageid="Add User" data-id="<?php echo base_url('home/view_modal/add_user');?>" id="menu" class="btn btn-primary">Add</button>
								</div>

							</div>
						</div>
						<div class="card-body">
							<table id="table_id" class="table">
							    <thead>
							        <tr>
							            <th>Sr. No.</th>
							            <th>Name</th>
							            <th>Email</th>
						              	<th>Mobile</th>
						               	<th>Date of Birth</th>
						               	<th>About Yourself</th>
							        </tr>
							    </thead>
							    <tbody>
							        
							    </tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--dynamic modal start-->
<div id="mymodal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
      <div class="modal-dialog modal-lg">
        <div class="modal-content p-0 b-0">
           <div class="modal-header">
                <h5 class="modal-title" id="page_title">Hii</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
              <div id="modal_loader" style="display: none; text-align: center;"> <img src="<?php echo base_url('uploads/preloader.gif'); ?>" /> </div>
              
              <!-- content will be load here -->
              <div id="dynamic-content"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.modal --> 
<!--dynamic modal end-->
<?php include('includes/script.php');?>
<?php include('includes/footer.php');?>