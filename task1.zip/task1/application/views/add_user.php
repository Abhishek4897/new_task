<?php 
$page_title='Add Address';
$this->session->unset_userdata('valuecaptchaCode');
$captchaImg = mt_rand(100,999); 
?>
<style>
.timer {
    width: 100px;
    font-size: 2.5em;
    text-align: center;
}
</style>
<div class="timer">
            <time id="countdown">3:00</time>
            <span id="timeout_message"></span>
        </div>
    <form action="<?=base_url('home/add_user')?>" method="post" id="imageUploadForm">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label for="first_name">Name</label>
                    <input type="text" name="name" class="form-control" id="name" required>
                 </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="email">E-mail:</label>
                    <input type="email" name="email" class="form-control" id="email" required>
                 </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="number">Mobile</label>
                    <input type="text" onKeyPress="if(this.value.length==10) return false;"  pattern="[6789][0-9]{9}" name="mobile" class="form-control"  id="number" required ="">
                 </div>
            </div>
             <div class="col-md-12">
                <div class="form-group">
                    <label for="address">Date Of Birth</label>
                    <input type="date" name="dob" class="form-control" required>
                 </div>
            </div>
             <div class="col-md-12">
                <div class="form-group">
                    <label for="address">About Yourself</label>
                    <textarea name="bio" class="form-control" rows="5" required></textarea>
                 </div>
            </div>
           <div class="uk-form-row">
                    <label>Captcha Code</lable>
                     <p id="image_captcha" style="font-size:30px"><?php echo $captchaImg; ?></p>                    <br/>
                     <?php $this->session->set_userdata('valuecaptchaCode',$captchaImg); ?>
                        <input class="md-input" name="captcha" placeholder="Enter Captcha" required value=""/>
                    </div>
           <div class="col-md-12" style="margin-top: 10px;">
                <button type="submit" id="submit_btn" name="add" value="1" class="btn btn-success">Add</button>
            </div>
           
            
        </div>
    </form>    
   <script>
          /*timer*/

      var seconds = 180;
      function secondPassed() {
          var minutes = Math.round((seconds - 30)/60),
              remainingSeconds = seconds % 60;

          if (remainingSeconds < 10) {
              remainingSeconds = "0" + remainingSeconds;
          }

          document.getElementById('countdown').innerHTML = minutes + ":" + remainingSeconds;
          if (seconds == 0) {
              clearInterval(countdownTimer);
           alert('session timeout');
           $('#timeout_message').html('Timeout.');
           $('#submit_btn').prop('disabled', true);
          
          } else {
              seconds--;
             $('#timeout_message').html('');
           $('#submit_btn').prop('disabled', false);

          }
      }
      var countdownTimer = setInterval('secondPassed()', 1000);
   </script>