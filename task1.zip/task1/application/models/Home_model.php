<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home_model extends CI_Model
{
    
    public function list_user($id="")
	{ 
		if($id){
			$query = $this->db->where('id',$id)->get('user')->row();
		return $query;
		} else{
			$query = $this->db->get('user')->result();
		return $query;
		}
		
	}

	 public function add_user(){
	 	$array=array(
	                "name"=>$this->input->post('name'),
	                "email"=>$this->input->post('email'),
	                "mobile"=>$this->input->post('mobile'),
	                "dob"=>$this->input->post('dob'),
	                 "bio"=>$this->input->post('bio'),
	                "status"=>1,
	                );
	 	
	             
		$this->db->insert('user', $array);
		return $this->db->insert_id();
	}

	public function update_user(){
		$id=$this->input->post('update');
		$array=array(
	                "name"=>$this->input->post('name'),
	                "email"=>$this->input->post('email'),
	                "mobile"=>$this->input->post('mobile')
	                );
	 	if($_FILES['image']!=""){
	 		$config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|png';
            // $config['max_size'] = 2000;
            // $config['max_width'] = 1500;
            // $config['max_height'] = 1500;
            $this->load->library('upload', $config);
            if(!$this->upload->do_upload('image')) {
            }else{
                 $data = $this->upload->data();
              $array['image'] =$data['file_name'];
            }
	 	}
	     $this->db->where('id',$id);
		$this->db->update('user', $array);        
		return $this->db->affected_rows();
	}

	public function delete_user(){
		$id=$this->input->post('id');
		return $this->db->delete('user',array('id' => $id));
	}
}
